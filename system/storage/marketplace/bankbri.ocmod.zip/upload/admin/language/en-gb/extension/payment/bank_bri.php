<?php
// Heading
$_['heading_title']    = 'Bank Transfer to BRI';

$_['heading_title2']      = 'Bank Transfer to BRI';

// Text 
$_['text_support']       = 'Feel free to send question or suggestion to';
$_['text_payment']       = 'Payment';
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success You have modified bank bri details!';
$_['text_edit']          = 'Edit Bank Transfer to bri';
$_['text_bank_bri'] = '<a onclick="window.open(\'http://mangroveinspiration.com\');"><img src="view/image/payment/bri_logo.jpg" alt="Bank bri" title="Bank bri" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_bank']         = 'Bank Transfer to bri Instructions';
$_['entry_total']				= 'Total';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_order_status']			= 'Order Status';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sort Order';

// Tab
$_['tab_help']   = 'Help';

// Help
$_['help_total']					= 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']   = 'Warning You do not have permission to modify payment Transfer to Bank bri!';
$_['error_bank']			= 'Bank Transfer to bri Instructions Required!';