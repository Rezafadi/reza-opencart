<?php
// Text
$_['text_title']       = 'Transfer to Bank BRI';
$_['text_instruction'] = 'Transfer to Bank BRI Instructions';
$_['text_description'] = 'Please transfer the total amount to the following bank account.';
$_['text_payment']     = 'Your order will not ship until we receive payment.';